<?php

use App\Http\Controllers\AchatController;
use App\Http\Controllers\CategorieController;
use App\Http\Controllers\MainController;
use App\Http\Controllers\ProduitController;
use App\Models\Produit;
use App\Models\Categorie;
use App\Http\Controllers\PlatController;
use App\Http\Controllers\TamponachatController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/',[AchatController::class, 'sedar'])->name('home');

Route::resource('plats', PlatController::class);


Route::get('/sedar',[AchatController::class, 'sedar'])->name('sedar');
Route::get('/sedarpdf', [AchatController::class, 'generatePdf'])->name('sedar.pdf');

Route::get('/sedar/commande', function(){
    return view('commande');
})->name('sedar.commande');

Route::post('/sedar/achat', [AchatController::class, 'save'])->name('sedar.achat');
Route::post('/sedar/search', [AchatController::class, 'search'])->name('sedar.search');




Route::get('/sedar/tampon', [TamponachatController::class, 'tampon'])->name('sedar.tampon.pdf');
