@extends('layout.base')
@section('contenu')
<div class="col-lg-4  offset-lg-4 mt-4 col-8 offset-2">
    <h5>Inscription | Authentification perso</h5>
    <hr>
    <form action="{{route('auth.check')}}" method="post">
        @csrf
        @method('POST')
        @if(Session::get('failure'))
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                <span class="sr-only">Close</span>
            </button>
            {{Session::get('failure')}}
        </div>
        @endif
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" name="email" id="validationServer02"
                class="form-control @if($errors->has('email')) is-invalid @endif"
                placeholder="Entrer votre adresse email" aria-describedby="helpId">
            @if($errors->has('email'))
            <small class="text-danger">{{$errors->first('email')}}</small>
            @endif
        </div>
        <div class="form-group">
            <label for="password">Password </label>
            <input type="password" name="password" id="validationServer03"
                class="form-control @if($errors->has('password')) is-invalid @endif"
                placeholder="Entrer votre mot de passe" aria-describedby="helpId">
            @if($errors->has('password'))
            <small class="text-danger">{{$errors->first('password')}}</small>
            @endif
        </div>
        <button type="submit" class="btn btn-block btn-primary">se connecter</button>
        <br>
        <a href="{{route('auth.register')}}">je n'ai pas de compte, je m'inscris</a>

    </form>


</div>
@endsection
