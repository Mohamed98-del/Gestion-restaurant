@extends('layout.base')
@section('title','Page d\'accueil')
@section('titrePage','Accueil')
@section('sousTitrePage', 'Page d\'accueil')
@section('contenu')

@endsection
