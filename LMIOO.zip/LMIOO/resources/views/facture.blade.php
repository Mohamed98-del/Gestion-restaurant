<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="/css/bootstrap.min.css">
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-12">
            <h3 class="text-center">FacturePour le client</h3>
        </div>
        <div class="col-12 bg-white mb-5">

            <table border="1px"class="table table-bordered">
                <thead class="thead-inverse">
                    <tr>
                        <th>Plat</th>
                        <th>Categorie</th>
                        <th>Prix Unitaire</th>
                        <th>Prix total</th>
                        <th>quantite</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($data as $achat)
                    <tr>
                        <td scope="row">{{$achat->nom}}</td>
                        <td>{{$achat->categorie}}</td>
                        <td>{{$achat->prix}} FCFA</td>
                        <td>{{$achat->prixtotal}}FCFA</td>
                        <td>{{$achat->quantite}}</td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
        <div class="col-12">
            <i class="fa fa-scissors" aria-hidden="true"></i>----------------------------------------------------------------------------
        </div>
        <div class="col-12 mt-5">
            <h3 class="text-center">Facture Pour le service de la cuisine</h3>
        </div>
        <div class="col-12 bg-white mb-5">

            <table border="0.3px"class="table table-bordered">
                <thead class="thead-inverse">
                    <tr>
                        <th>Plat</th>
                        <th>Categorie</th>
                        <th>Prix Unitaire</th>
                        <th>Prix total</th>
                        <th>quantite</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($data as $achat)
                    <tr>
                        <td scope="row">{{$achat->nom}}</td>
                        <td>{{$achat->categorie}}</td>
                        <td>{{$achat->prix}} FCFA</td>
                        <td>{{$achat->prixtotal}}FCFA</td>
                        <td>{{$achat->quantite}}</td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>

     <h1>Total: </h1><h3>{{$prixtotal}} FCFA</h3>
    </div>



</div>
    <script src="/js/bootstrap.min.js"></script>
</body>
</html>
