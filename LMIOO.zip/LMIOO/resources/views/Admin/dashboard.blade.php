@extends('layout.base')
@section('contenu')
<div class="col-4 offset-4 col-md-6 offset-md-3">
    <h4>L'utilisateur est connect&eacute;</h4>
    <table class="table table-hover">
        <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td scope="row">{{$LoggedUserInfo['name']}}</td>
                <td>{{$LoggedUserInfo['email']}}</td>
                <td><a href="{{route('auth.logout')}}">logout</a></td>
            </tr>
        </tbody>
    </table>
</div>
@endsection
