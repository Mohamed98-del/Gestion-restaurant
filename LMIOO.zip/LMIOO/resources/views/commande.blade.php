@extends('layout.base')
@section('contenu')
<div class="container">
    <div class="row">
        @if(Session::get('success'))
        <div class="col-8 offset-2 col-lg-6 offset-lg-3 col-md-10 offset-md-1 mt-5">
            <div class="alert alert-primary alert-dismissible fade show" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    <span class="sr-only">Close</span>
                </button>
                {{Session::get('success')}}
            </div>
        </div>
        @endif
        <div class="col-8 offset-2 col-lg-6 offset-lg-3 col-md-10 offset-md-1 mt-5">
            <h3 class="bg-warning text-center text-white">Page de commande</h3>
        </div>
        <div class="col-8 offset-2 col-lg-6 offset-lg-3 col-md-10 offset-md-1 mt-5">
            <form action="{{route('sedar.achat')}}" method="post">
                @csrf
                @method('POST')
                <div class="container">
                    <div class="row">
                        <div class="col-sm-8 col-lg-8">

                            <div class="form-group">
                                <label for="plat"><span class="badge badge-warning">Plat:</span></label>
                                <select class="form-control" name="plat_id" id="plat_id">
                                    <optgroup label="Viande">
                                        <option value="3">Hamburger</option>
                                        {{-- <option value="">Yassa yapp</option> --}}
                                    <optgroup label="Poisson">
                                        {{-- <option value="">Poisson brais&eacute;</option> --}}
                                        <option value="2">yass djeune</option>
                                    <optgroup label="Glace">
                                        <option value="1">Creme Glace</option>
                                        {{-- <option value="">jus de fruit</option> --}}
                                    <optgroup label="Patisserie">
                                        <option value="4">Croissant</option>
                                        {{-- <option value="">Cakes</option> --}}
                                    <optgroup label="Boisson">
                                        <option value="5">jus de fruit</option>
                                        {{-- <option value="">Cakes</option> --}}
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-4 col-lg-4">
                            <div class="form-group">
                                <label for="quantite"><span class="badge badge-warning">Quantite:</span></label>
                                <input type="number" class="form-control @if($errors->has('quantite')) is-invalid @endif" name="quantite" id="quantite" aria-describedby="helpId">
                                @if($errors->has('quantite'))
                                <small class="text-danger">{{$errors->first('quantite')}}</small>
                                @endif
                            </div>

                        </div>
                    </div>

                    <div class="row">
                        <div class="col-6">
                            <button type="submit" class="btn btn-primary float-left">Acheter</button>
                        </div>
                        <div class="col-6">
                            <a href="{{route('sedar.tampon.pdf')}}" class="btn btn-danger float-right">finaliser</a>
                        </div>
                    </div>
                </div>

        </div>
    </div>
</div>
@endsection
