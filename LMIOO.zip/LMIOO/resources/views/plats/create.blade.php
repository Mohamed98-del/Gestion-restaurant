@extends('layout.base')
@section('contenu')
<div class="col-lg-4  offset-lg-4 mt-4 col-8 offset-2 bg-white">
    <div class="row">

        <form action="{{route('plats.store')}}"" method="post">
            @csrf
            @method('PUT')
            <div class="form-group col-12">
                <label for="nom">Nom:</label>
                <input type="text" name="nom" value="{{old('nom')}}" id="validationServer01"
                    class="form-control @if($errors->has('nom')) is-invalid @endif" placeholder=""
                    aria-describedby="helpId">
                @if($errors->has('nom'))
                <small id="helpId" class="text-danger">{{$errors->first('nom')}}</small>
                @endif
            </div>

            <div class="form-group col-12">
                <label for="prix">Prix:</label>
                <input type="text" name="prix" value="{{old('prix')}}" id="validationServer03"
                    class="form-control @if($errors->has('prix')) is-invalid @endif" placeholder=""
                    aria-describedby="helpId">
                @if($errors->has('prix'))
                <small id="helpId" class="text-danger">{{$errors->first('prix')}}</small>
                @endif
            </div>

            <div class="form-group col-12">
                <label for="prix">Prix:</label>
                <input type="text" name="prix" value="{{old('nom_photo')}}" id="validationServer03"
                    class="form-control @if($errors->has('nom_photo')) is-invalid @endif" placeholder=""
                    aria-describedby="helpId">
                @if($errors->has('nom_photo'))
                <small id="helpId" class="text-danger">{{$errors->first('prix')}}</small>
                @endif
            </div>
            <div class="form-group col-12">
              <label for="">Categorie</label>
              <select class="form-control" name="categorie" id="">
                <option>yuyu</option>
                <option>hiuoh</option>
                <option>uiuigg</option>
              </select>
            </div>

            <div class="pull-left mt-4">
                <button type="submit" class="btn btn-primary">Enregistrer</button>
            </div>
        </form>
    </div>
</div>



@endsection
