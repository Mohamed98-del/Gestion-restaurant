@extends('layout.base')
@section('contenu')
<div class="mt-4 col-10 offset-1">
    <div class="row">
        <div class="col-lg-5 col-md-8 col-12">
            <img src="/img/recette/4.jpg" style="width: 200px; height: 200px">
        </div>
        <div class="col-lg-6 col-md-8 col-12">

            <form action="{{route('plats.update', compact('plat'))}}"" method="post">
                @csrf
                @method('PUT')
                <div class="form-group">
                    <label for="nom">Nom:</label>
                    <input type="text" name="nom" value="{{$plat->nom}}" id="validationServer01"
                        class="form-control @if($errors->has('nom')) is-invalid @endif" placeholder=""
                        aria-describedby="helpId">
                    @if($errors->has('nom'))
                    <small id="helpId" class="text-danger">{{$errors->first('nom')}}</small>
                    @endif
                </div>

                <div class="form-group">
                    <label for="prix">Prix:</label>
                    <input type="number" name="prix" value="{{$plat->prix}}" id="validationServer03"
                        class="form-control @if($errors->has('prix')) is-invalid @endif" placeholder=""
                        aria-describedby="helpId">
                    @if($errors->has('prix'))
                    <small id="helpId" class="text-danger">{{$errors->first('prix')}}</small>
                    @endif
                </div>

                <div class="form-group">
                    <label for="prix">Nom du photo:</label>
                    <input type="text" name="nom_photo" value="{{$plat->nom_photo}}" id="validationServer03"
                        class="form-control @if($errors->has('nom_photo')) is-invalid @endif" placeholder=""
                        aria-describedby="helpId">
                    @if($errors->has('nom_photo'))
                    <small id="helpId" class="text-danger">{{$errors->first('nom_photo')}}</small>
                    @endif
                </div>

                <div class="pull-left mt-4">
                    <button type="submit" class="btn btn-primary">Enregistrer</button>
                </div>
            </form>
        </div>

    </div>
</div>



@endsection
