@extends('layout.base')
@section('contenu')

<div class="col-12">

    <a href="{{route('plats.create')}}" title="Ajouter un plat" class="btn btn-primary btn-rounded float-right"><i
            class="fa fa-plus-circle"></i></a>
</div>
@foreach ($plats as $plat)
<div class="col-6 col-md-4 col-lg-3 p-2">
    <div class="card">
        <img class="card-img-top img-responsive" src="/img/boutique.jpg" alt="boutique">
        <div class="card-body">
            <h4 class="card-title">{{$plat->nom}}</h4>
            <p class="card-text">{{$plat->prix}}</p>
        </div>
        <div class="d-flex justify-content-end">
            <a href="{{route('plats.show', compact('plat'))}}" class="btn btn-rounded btn-primary mr-2 mb-2"
                title="afficher la description"><i class="fa fa-eye" aria-hidden="true"></i></a>

            <a href="{{route('plats.edit', compact('plat'))}}" class="btn btn-rounded btn-primary mr-2 mb-2"
                title="afficher la description"><i class="fa fa-eyedropper" aria-hidden="true"></i></a>


            <form action="{{route('plats.destroy', compact('plat'))}}" method="post">
                @csrf
                @method('DELETE')
                <button type="submit" class="btn btn-primary btn-rounded mr-2" title="supprimer le produit"><i
                        class="fa fa-trash" aria-hidden="true"></i></button>
            </form>
        </div>
    </div>
</div>

@endforeach

@endsection
