<?php $__env->startSection('contenu'); ?>
<div class="col-lg-4  offset-lg-4 mt-4 col-8 offset-2 bg-white">
    <div class="row">

        <form action="<?php echo e(route('plats.store')); ?>"" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group col-12">
                <label for="nom">Nom:</label>
                <input type="text" name="nom" value="<?php echo e(old('nom')); ?>" id="validationServer01"
                    class="form-control <?php if($errors->has('nom')): ?> is-invalid <?php endif; ?>" placeholder=""
                    aria-describedby="helpId">
                <?php if($errors->has('nom')): ?>
                <small id="helpId" class="text-danger"><?php echo e($errors->first('nom')); ?></small>
                <?php endif; ?>
            </div>

            <div class="form-group col-12">
                <label for="prix">Prix:</label>
                <input type="text" name="prix" value="<?php echo e(old('prix')); ?>" id="validationServer03"
                    class="form-control <?php if($errors->has('prix')): ?> is-invalid <?php endif; ?>" placeholder=""
                    aria-describedby="helpId">
                <?php if($errors->has('prix')): ?>
                <small id="helpId" class="text-danger"><?php echo e($errors->first('prix')); ?></small>
                <?php endif; ?>
            </div>

            <div class="form-group col-12">
                <label for="prix">Prix:</label>
                <input type="text" name="prix" value="<?php echo e(old('nom_photo')); ?>" id="validationServer03"
                    class="form-control <?php if($errors->has('nom_photo')): ?> is-invalid <?php endif; ?>" placeholder=""
                    aria-describedby="helpId">
                <?php if($errors->has('nom_photo')): ?>
                <small id="helpId" class="text-danger"><?php echo e($errors->first('prix')); ?></small>
                <?php endif; ?>
            </div>
            <div class="form-group col-12">
              <label for="">Categorie</label>
              <select class="form-control" name="categorie" id="">
                <option>yuyu</option>
                <option>hiuoh</option>
                <option>uiuigg</option>
              </select>
            </div>

            <div class="pull-left mt-4">
                <button type="submit" class="btn btn-primary">Enregistrer</button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/ahmad/Mohamed/Fofana/LMIOO/resources/views/plats/create.blade.php ENDPATH**/ ?>