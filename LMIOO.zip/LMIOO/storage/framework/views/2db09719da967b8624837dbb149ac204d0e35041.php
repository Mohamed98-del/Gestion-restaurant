<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <title>Title</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">

    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>

<body class="antialiased">
    <div class="container-fluid">
        <nav class="navbar navbar-expand-lg bg-primary justify-content-center">
            <ul class="navbar-nav">
                <li class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle text-white" id="navbardrop"
                        data-toggle="dropdown">Fruits et L&eacute;gumes-Panier</a>
                    <div class="dropdown-menu bg-primary">
                        <a class="dropdown-item text-black" href="#">link</a>
                        <a class="dropdown-item text-white" href="#">link</a>
                        <a class="dropdown-item text-white" href="#">link</a>
                    </div>
                </li>

                <li class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle text-white" id="navbardrop"
                        data-toggle="dropdown">Produits Frais</a>
                    <div class="dropdown-menu bg-primary">
                        <a class="dropdown-item text-white" href="#">link</a>
                        <a class="dropdown-item text-white" href="#">link</a>
                        <a class="dropdown-item text-white" href="#">link</a>
                        <a class="dropdown-item text-white" href="#">link</a>
                    </div>
                </li>

                <li class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle text-white" id="navbardrop"
                        data-toggle="dropdown">Viande</a>
                    <div class="dropdown-menu bg-primary">
                        <a class="dropdown-item text-white" href="#">linka</a>
                        <a class="dropdown-item text-white" href="#">linkb</a>
                        <a class="dropdown-item text-white" href="#">linkc</a>
                    </div>
                </li>

                <li class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle text-white" id="navbardrop"
                        data-toggle="dropdown">&Eacute;picerie</a>
                    <div class="dropdown-menu bg-primary">
                        <a class="dropdown-item text-white" href="#">linka</a>
                        <a class="dropdown-item text-white" href="#">linkb</a>
                        <a class="dropdown-item text-white" href="#">linkb</a>
                    </div>
                </li>

                <li class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle text-white" id="navbardrop"
                        data-toggle="dropdown">Boisson</a>
                    <div class="dropdown-menu bg-primary">
                        <a class="dropdown-item text-white" href="#">reugf1</a>
                        <a class="dropdown-item text-white" href="#">niania</a>
                        <a class="dropdown-item text-white" href="#">niania3</a>
                    </div>
                </li>

                <li class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle text-white" id="navbardrop"
                        data-toggle="dropdown">B&eacute;b&eacute;</a>
                    <div class="dropdown-menu bg-primary">
                        <a class="dropdown-item text-white" href="#">niania</a>
                        <a class="dropdown-item text-white" href="#">niania</a>
                        <a class="dropdown-item text-white" href="#">niania</a>
                    </div>
                </li>

                <li class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle text-white" id="navbardrop"
                        data-toggle="dropdown">Droguerie</a>
                    <div class="dropdown-menu bg-primary">
                        <a class="dropdown-item text-white" href="#">link</a>
                        <a class="dropdown-item text-white" href="#">link</a>
                        <a class="dropdown-item text-white" href="#">link</a>
                    </div>
                </li>

            </ul>
        </nav>

        <?php echo $__env->yieldContent('headings'); ?>

    </div>
</body>




<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous">
</script>
</body>

</html>
<?php /**PATH /media/ahmad/Mohamed/Fofana/fofana-laravel/resources/views/app.blade.php ENDPATH**/ ?>