<?php $__env->startSection('title','Page d\'accueil'); ?>
<?php $__env->startSection('titrePage','Accueil'); ?>
<?php $__env->startSection('sousTitrePage', 'Page d\'accueil'); ?>
<?php $__env->startSection('contenu'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/ahmad/Mohamed/Fofana/LMIOO/resources/views/welcome.blade.php ENDPATH**/ ?>