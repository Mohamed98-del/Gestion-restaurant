<?php $__env->startSection('contenu'); ?>
<div class="col-12 d-flex justify-content-center mt-5">
    <span class="badge badge-warning"><span class="display-3">Le Plat</span></span>
</div>
<div class="col-12 mt-5">
    <table class="table table-warning table-hover table-responsive-sm">
        <thead>
            <tr>
                <th scope="col">Num&eacute;ro</th>
                <th scope="col">Nom</th>
                <th scope="col">Prix</th>

            </tr>
        </thead>
        <tbody>
            <tr>
                <th scope="row"><?php echo e($plat->id); ?></th>
                <td><?php echo e($plat->nom); ?></td>
                <td><?php echo e($plat->prix); ?></td>
            </tr>

        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/ahmad/Mohamed/Fofana/LMIOO/resources/views/plats/show.blade.php ENDPATH**/ ?>