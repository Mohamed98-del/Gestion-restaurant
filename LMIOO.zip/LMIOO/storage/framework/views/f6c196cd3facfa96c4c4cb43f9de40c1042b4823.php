
<?php /**PATH /media/ahmad/Mohamed/Fofana/fofana-cours/resources/views/products/edit.blade.php ENDPATH**/ ?>