<?php $__env->startSection('headings'); ?>
<div class="jumbotron text-center">
    <h1>My First superMarket dashboard</h1>
    <p>Welcome in my supermarket website Here be like at Home</p>
</div>
<nav class="navbar navbar-expand-sm navbar-light">
    <a href="#" class="navbar-brand" >NdoyeSup</a>
    <div class="collapse navbar-collapse" id="collapsibleNavbar">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" href="#">Marche</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">Foir</a>
            </li>
        </ul>
    </div>
</nav>
<div class="container-fluid" style="margin-top: 30px">
    <div class="row">
        <div class="col-sm-4">
            <h2>About Me<h2>
            <h5>Photo of me:</h5>
            <div class="fakeimg">Fake Image</div>
            <p>Some text about me in culpa qui officia deserunt mollit anim..</p>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/ahmad/Mohamed/Fofana/fofana-laravel/resources/views/diangue.blade.php ENDPATH**/ ?>