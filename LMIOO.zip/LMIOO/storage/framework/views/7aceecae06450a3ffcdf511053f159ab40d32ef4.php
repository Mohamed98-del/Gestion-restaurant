<?php $__env->startSection('contenu'); ?>
<div class="col-lg-4  offset-lg-4 mt-4 col-8 offset-2">
    <h5>Inscription | Authentification perso</h5>
    <hr>
    <form action="<?php echo e(route('auth.check')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('POST'); ?>
        <?php if(Session::get('failure')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                <span class="sr-only">Close</span>
            </button>
            <?php echo e(Session::get('failure')); ?>

        </div>
        <?php endif; ?>
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" name="email" id="validationServer02"
                class="form-control <?php if($errors->has('email')): ?> is-invalid <?php endif; ?>"
                placeholder="Entrer votre adresse email" aria-describedby="helpId">
            <?php if($errors->has('email')): ?>
            <small class="text-danger"><?php echo e($errors->first('email')); ?></small>
            <?php endif; ?>
        </div>
        <div class="form-group">
            <label for="password">Password </label>
            <input type="password" name="password" id="validationServer03"
                class="form-control <?php if($errors->has('password')): ?> is-invalid <?php endif; ?>"
                placeholder="Entrer votre mot de passe" aria-describedby="helpId">
            <?php if($errors->has('password')): ?>
            <small class="text-danger"><?php echo e($errors->first('password')); ?></small>
            <?php endif; ?>
        </div>
        <button type="submit" class="btn btn-block btn-primary">se connecter</button>
        <br>
        <a href="<?php echo e(route('auth.register')); ?>">je n'ai pas de compte, je m'inscris</a>

    </form>


</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/ahmad/Mohamed/Fofana/fofana-cours/resources/views/auth/login.blade.php ENDPATH**/ ?>