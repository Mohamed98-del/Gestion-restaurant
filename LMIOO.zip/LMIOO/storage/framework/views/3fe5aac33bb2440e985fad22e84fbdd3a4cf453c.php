<?php $__env->startSection('contenu'); ?>

<div class="col-12">

    <a href="<?php echo e(route('products.create')); ?>" title="Ajouter un Produit" class="btn btn-primary btn-rounded float-right"><i class="fa fa-plus-circle"></i></a>
</div>
<?php $__currentLoopData = $produits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-6 col-md-4 col-lg-3 p-2">
    <div class="card">
        <img class="card-img-top img-responsive" src="/img/boutique.jpg" alt="boutique">
        <div class="card-body">
            <h4 class="card-title"><?php echo e($produit->nom); ?></h4>
            <p class="card-text"><?php echo e($produit->adresse); ?></p>
            <p class="card-text"><?php echo e($produit->telephone); ?></p>
            <p class="card-text"><?php echo e($produit->statut); ?></p>
        </div>
        <div class="d-flex justify-content-end">
            <a href="<?php echo e(route('products.show', $produit->id)); ?>" class="btn btn-rounded btn-primary mr-2 mb-2" title="afficher la description"><i class="fa fa-eye" aria-hidden="true"></i></a>
            <a href="<?php echo e(route('products.edit', compact('produit'))); ?>" class="btn btn-rounded btn-primary mr-2 mb-2" title="afficher la description"><i class="fa fa-eyedropper" aria-hidden="true"></i></a>
            <form action="<?php echo e(route('products.destroy', compact('produit'))); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-primary btn-rounded mr-2" title="supprimer le produit"><i class="fa fa-trash" aria-hidden="true"></i></button>
            </form>
        </div>
    </div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/ahmad/Mohamed/Fofana/fofana-cours/resources/views/products/index.blade.php ENDPATH**/ ?>