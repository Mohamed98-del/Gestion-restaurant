<?php $__env->startSection('contenu'); ?>
<div class="col-12 d-flex justify-content-center">
    <span class="display-5">Description de la boutique</span>
</div>
<div class="col-12">
    <table class="table table-dark table-responsive-sm  ">
        <thead>
            <tr>
                <th scope="col">Num&eacute;ro</th>
                <th scope="col">Nom</th>
                <th scope="col">Prix</th>
                <th scope="col">QuantiteEnStock</th>
                <th scope="col">Etat</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <th scope="row"><?php echo e($boutique->id); ?></th>
                <td><?php echo e($boutique->nom); ?></td>
                <td><?php echo e($boutique->adresse); ?></td>
                <td><?php echo e($boutique->telephone); ?></td>
                <td><?php echo e($boutique->statut); ?></td>
            </tr>

        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/ahmad/Mohamed/Fofana/fofana-cours/resources/views/boutiques/show.blade.php ENDPATH**/ ?>