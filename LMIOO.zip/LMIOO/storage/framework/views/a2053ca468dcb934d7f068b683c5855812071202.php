<?php $__env->startSection('title', 'page d\'affichage du produit'); ?>
<?php $__env->startSection('contenu'); ?>
<?php dump($produit->quantiteEnStock); ?>
<div class="col-12">

    <div class="row">
        <div class="col-12 d-flex justify-content-center">
            <span class="display-4">Description du produit</span>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <table class="table table-dark">
                <thead>
                    <tr>
                        <th scope="col">Num&eacute;ro</th>
                        <th scope="col">Nom:</th>
                        <th scope="col">Prix</th>
                        <th scope="col">QuantiteEnStock</th>
                        <th scope="col">Etat</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <th scope="row"><?php echo e($produit->id); ?></th>
                        <td><?php echo e($produit->nom); ?></td>
                        <td><?php echo e($produit->prix); ?></td>
                        <td><?php echo e($produit->quantiteEnStock); ?></td>
                        <td><?php echo e($produit->etat); ?></td>
                    </tr>

                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/ahmad/Mohamed/Fofana/fofana-cours/resources/views/products/show.blade.php ENDPATH**/ ?>