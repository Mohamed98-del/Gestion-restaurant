<?php $__env->startSection('contenu'); ?>
<form action="<?php echo e(route('boutiques.store')); ?>" method="post">
    <div class="col-12">

        <?php echo csrf_field(); ?>
        <?php echo method_field('POST'); ?>
        <div class="row">

            <div class="col-12 col-md-6 col-lg-4">
                <label for="nom">Nom:</label>
                <input type="text" name="nom" value="<?php echo e(old('nom')); ?>" id="validationServer01" class="form-control <?php if($errors->has('nom')): ?> is-invalid <?php endif; ?>" placeholder=""
                    aria-describedby="helpId">
                <?php if($errors->has('nom')): ?>
                <small id="helpId" class="text-danger"><?php echo e($errors->first('nom')); ?></small>
                <?php endif; ?>
            </div>
            <div class="form-group col-12 col-md-6 col-lg-4">
                <label for="adresse">Adresse:</label>
                <input type="text" name="adresse" value="<?php echo e(old('adresse')); ?>" id="validationServer02" class="form-control <?php if($errors->has('adresse')): ?> is-invalid <?php endif; ?>"
                    placeholder="" aria-describedby="helpId">
                <?php if($errors->has('adresse')): ?>
                <small id="helpId" class="text-danger"><?php echo e($errors->first('adresse')); ?></small>
                <?php endif; ?>
            </div>
            <div class="form-group col-12 col-md-6 col-lg-4">
                <label for="telephone">Telephone:</label>
                <input type="text" name="telephone" value="<?php echo e(old('telephone')); ?>" id="validationServer03" class="form-control <?php if($errors->has('telephone')): ?> is-invalid <?php endif; ?>"
                    placeholder="" aria-describedby="helpId">
                <?php if($errors->has('telephone')): ?>
                <small id="helpId" class="text-danger"><?php echo e($errors->first('telephone')); ?></small>
                <?php endif; ?>
            </div>
            <div class="form-check col-12 col-md-6 col-lg-4">
                <div class="form-check">

                    <label class="form-check-label">
                        <input type="radio" class="form-check-input" name="statut" id="" value="true" checked>
                        Ouvert
                    </label>
                </div>
                <div class="form-check">

                    <label class="form-check-label d-block">
                        <input type="radio" class="form-check-input" name="statut" id="" value="false">
                        Ferm&eacute;
                    </label>
                </div>
            </div>
        </div>
        <div class="pull-left mt-4">
            <button type="submit" class="btn btn-primary">Enregistrer</button>
        </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/ahmad/Mohamed/Fofana/LMIOO/resources/views/restaurants/create.blade.php ENDPATH**/ ?>