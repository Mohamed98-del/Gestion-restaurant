<?php $__env->startSection('contenu'); ?>
<div class="col-lg-4  offset-lg-4 mt-4 col-8 offset-2">

    <form role="form" action="<?php echo e(route('products.store')); ?>" method="POST">
        <?php echo method_field('POST'); ?>
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="nom">Nom</label>
            <input value="<?php echo e(old('nom')); ?>" class="form-control <?php if($errors->has('nom')): ?> is-invalid <?php endif; ?>" type="text" name="nom" id="nom">
        </div>
        <?php if($errors->has('prix')): ?>
            <small class="text-danger"><?php echo e($errors->first('prix')); ?></small>
            <?php endif; ?>
        <div class="form-group">
            <label for="prix">Prix</label>
            <input name="prix" id="prix" value="<?php echo e(old('prix')); ?>" min="1" class="form-control <?php if($errors->has('prix')): ?> is-invalid <?php endif; ?>"
                type="number">
            <?php if($errors->has('prix')): ?>
            <small class="text-danger"><?php echo e($errors->first('prix')); ?></small>
            <?php endif; ?>
        </div>
        <div class="form-group">
            <label for="quantiteEnStock">Quantité en Stock</label>
            <input value="<?php echo e(old('quantiteEnStock')); ?>" min="0" class="form-control <?php if($errors->has('quantiteEnStock')): ?> is-invalid <?php endif; ?>" type="number"
                name="quantiteEnStock" id="quantiteEnStock">
            <?php if($errors->has('quantiteEnStock')): ?>
            <small class="text-danger"><?php echo e($errors->first('quantiteEnStock')); ?></small>
            <?php endif; ?>
        </div>
        <div class="form-group">
            <label for="code">Code</label>
            <input value="<?php echo e(old('code')); ?>" class="form-control <?php if($errors->has('code')): ?> is-invalid <?php endif; ?>" type="text" name="code" id="code">
            <?php if($errors->has('code')): ?>
            <small class="text-danger"><?php echo e($errors->first('code')); ?></small>
            <?php endif; ?>
        </div>
        <div class="form-group">
            <label for="couleur">Couleur</label>
            <div class="row">
                <div class="col-lg-4  offset-lg-4 mt-4 col-8 offset-2">
                    <input value="<?php echo e(old('couleur')); ?>" class="form-control" type="color" name="couleur" id="couleur">
                </div>
            </div>
        </div>
        <div class="form-check">
            <label class="form-check-label">
                <input type="radio" class="form-check-input" name="etat" checked>Actif
            </label>
        </div>
        <div class="form-check">
            <label class="form-check-label">
                <input type="radio" class="form-check-input" name="etat">Inactif
            </label>
        </div>
        <div class="col-12">
            <button type="submit" class="btn btn-primary float-right ml-2">Enregistrer</button>
            <button type="reset" class="btn btn-secondary float-right">
                Vider <i class="fa fa-refresh" aria-hidden="true"></i>
            </button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/ahmad/Mohamed/Fofana/fofana-cours/resources/views/products/create.blade.php ENDPATH**/ ?>