<?php $__env->startSection('title', 'contact'); ?>
<?php $__env->startSection('content'); ?>

<p class="text-center display-1">Contactez-Nous</p>
<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vitae harum voluptatem quam porro eum, temporibus, vero
    mollitia labore odit hic animi iure quisquam enim eligendi assumenda dicta. Fuga, laboriosam voluptas? Lorem ipsum
    dolor sit amet consectetur adipisicing elit. Voluptatibus perferendis aspernatur impedit ea esse eius, nemo
    repudiandae numquam, atque enim ipsum aliquam quia ab? Nulla maiores rem velit corrupti incidunt!</p>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/ahmad/Mohamed/Fofana/fofana-cours/resources/views/contact.blade.php ENDPATH**/ ?>