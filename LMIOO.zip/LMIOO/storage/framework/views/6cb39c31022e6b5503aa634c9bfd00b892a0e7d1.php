<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="/css/bootstrap.min.css">
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-12">
            <h3 class="text-center">Liste des ventes</h3>
        </div>
        <div class="col-12 bg-white mb-5">

            <table border="1px"class="table table-bordered">
                <thead class="thead-inverse">
                    <tr>
                        <th>Plat</th>
                        <th>Categorie</th>
                        <th>Prix Unitaire</th>
                        <th>Prix total</th>
                        <th>quantite</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $achat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td scope="row"><?php echo e($achat->nom); ?></td>
                        <td><?php echo e($achat->categorie); ?></td>
                        <td><?php echo e($achat->prix); ?> FCFA</td>
                        <td><?php echo e($achat->prixtotal); ?>FCFA</td>
                        <td><?php echo e($achat->quantite); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
    <script src="/js/bootstrap.min.js"></script>
</body>
</html>
<?php /**PATH /media/ahmad/Mohamed/Fofana/LMIOO/resources/views/liste.blade.php ENDPATH**/ ?>