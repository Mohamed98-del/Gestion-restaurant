<?php $__env->startSection('contenu'); ?>
<div class="container">
    <div class="row">
        <?php if(Session::get('success')): ?>
        <div class="col-8 offset-2 col-lg-6 offset-lg-3 col-md-10 offset-md-1 mt-5">
            <div class="alert alert-primary alert-dismissible fade show" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    <span class="sr-only">Close</span>
                </button>
                <?php echo e(Session::get('success')); ?>

            </div>
        </div>
        <?php endif; ?>
        <div class="col-8 offset-2 col-lg-6 offset-lg-3 col-md-10 offset-md-1 mt-5">
            <h3 class="bg-warning text-center text-white">Page de commande</h3>
        </div>
        <div class="col-8 offset-2 col-lg-6 offset-lg-3 col-md-10 offset-md-1 mt-5">
            <form action="<?php echo e(route('sedar.achat')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('POST'); ?>
                <div class="container">
                    <div class="row">
                        <div class="col-sm-8 col-lg-8">

                            <div class="form-group">
                                <label for="plat"><span class="badge badge-warning">Plat:</span></label>
                                <select class="form-control" name="plat_id" id="plat_id">
                                    <optgroup label="Viande">
                                        <option value="3">Hamburger</option>
                                        
                                    <optgroup label="Poisson">
                                        
                                        <option value="2">yass djeune</option>
                                    <optgroup label="Glace">
                                        <option value="1">Creme Glace</option>
                                        
                                    <optgroup label="Patisserie">
                                        <option value="4">Croissant</option>
                                        
                                    <optgroup label="Boisson">
                                        <option value="5">jus de fruit</option>
                                        
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-4 col-lg-4">
                            <div class="form-group">
                                <label for="quantite"><span class="badge badge-warning">Quantite:</span></label>
                                <input type="number" class="form-control <?php if($errors->has('quantite')): ?> is-invalid <?php endif; ?>" name="quantite" id="quantite" aria-describedby="helpId">
                                <?php if($errors->has('quantite')): ?>
                                <small class="text-danger"><?php echo e($errors->first('quantite')); ?></small>
                                <?php endif; ?>
                            </div>

                        </div>
                    </div>

                    <div class="row">
                        <div class="col-6">
                            <button type="submit" class="btn btn-primary float-left">Acheter</button>
                        </div>
                        <div class="col-6">
                            <a href="<?php echo e(route('sedar.tampon.pdf')); ?>" class="btn btn-danger float-right">finaliser</a>
                        </div>
                    </div>
                </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/ahmad/Mohamed/Fofana/LMIOO/resources/views/commande.blade.php ENDPATH**/ ?>