<?php $__env->startSection('contenu'); ?>
<div class="col-lg-10 offset-lg-1 mt-5 bg-danger">
    <?php if($platsFound ?? ''): ?>
    <?php $__currentLoopData = $platsFound; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $found): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <ul class="list-group">
        <li class="list-group-item"><?php echo e($found->nom); ?></li>
    </ul>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</div>
<div class="col-12">
    <div class="row">
        <div class="col-12 bg-warning mt-4">
            <h3 class="text-center"><span class="text-white">Restaurant</span> <span class="badge badge-primary">Sedar
                    Eat</span></h3>
        </div>
    </div>
</div>


<div class="col-12 mb-5 mt-3">
    <div class="container">
        <div class="row">

            <div class="col-lg-10 offset-lg-1 mt-5">
                <span class="text-center no-wrap d-block text-warning" style="font-size: 2rem;"><strong>
                        <a href="<?php echo e(route('sedar.commande')); ?>" class="btn"
                            style="background-color: white;"><strong>D&eacute;marrer un processus de vente</strong></a>
                    </strong><span class="badge badge-primary">Sedar
                        Eat</span></span>
                <hr style="background-color: rgb(255, 230, 0); heigth: 1px">
            </div>
        </div>
    </div>
</div>




<div class="col-10 offset-1 mb-5 mt-5">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div id="carouselExampleControls" class="carousel slide mt-5" data-ride="carousel">
                    <ol class="carousel-indicators">
                        <li data-target="#carouselExampleControls" data-slide-to="0" class="active"></li>
                        <li data-target="#carouselExampleControls" data-slide-to="1"></li>
                        <li data-target="#carouselExampleControls" data-slide-to="2"></li>
                    </ol>
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <img class="d-block w-100" src="/img/recette/5.jpg" alt="First slide">
                        </div>
                        <div class="carousel-item">
                            <img class="d-block w-100" src="/img/recette/5.jpg" alt="Second slide">
                        </div>
                        <div class="carousel-item">
                            <img class="d-block w-100" src="/img/recette/5.jpg" alt="Third slide">
                        </div>
                    </div>
                    <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                    </a>
                </div>
            </div>
        </div>
    </div>

</div>


<div class="col-lg-10 offset-lg-1 mt-5">
    <span class="text-center d-block bg-warning" style="font-size: 2rem;"><strong>
            <strong>Liste des ventes</strong>
        </strong></span>
    <hr style="background-color: rgb(255, 230, 0); heigth: 1px">
</div>


<div class="col-12 bg-white mb-5">
    <table class="table table-striped table-inverse table-responsive-sm">
        <thead class="thead-inverse">
            <tr>
                <th>Plat</th>
                <th>Categorie</th>
                <th>Prix Unitaire</th>
                <th>Prix total</th>
                <th>Quantite</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $achats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $achat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td scope="row"><?php echo e($achat->nom); ?></td>
                <td><?php echo e($achat->categorie); ?></td>
                <td><?php echo e($achat->prixtotal); ?>FCFA</td>
                <td><?php echo e($achat->prix); ?> FCFA</td>
                <td><?php echo e($achat->quantite); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<div class="col-10 offset-1 mb-5 mt-5">
    <a href="<?php echo e(route('sedar.pdf')); ?>" class="float-right btn btn-danger">convert to pdf<i class="fa fa-download"
            aria-hidden="true"></i></a>
</div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/ahmad/Mohamed/Fofana/LMIOO/resources/views/sedar.blade.php ENDPATH**/ ?>