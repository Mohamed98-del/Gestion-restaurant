<?php $__env->startSection('contenu'); ?>
<div class="mt-4 col-10 offset-1">
    <div class="row">
        <div class="col-lg-5 col-md-8 col-12">
            <img src="/img/recette/4.jpg" style="width: 200px; height: 200px">
        </div>
        <div class="col-lg-6 col-md-8 col-12">

            <form action="<?php echo e(route('plats.update', compact('plat'))); ?>"" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="form-group">
                    <label for="nom">Nom:</label>
                    <input type="text" name="nom" value="<?php echo e($plat->nom); ?>" id="validationServer01"
                        class="form-control <?php if($errors->has('nom')): ?> is-invalid <?php endif; ?>" placeholder=""
                        aria-describedby="helpId">
                    <?php if($errors->has('nom')): ?>
                    <small id="helpId" class="text-danger"><?php echo e($errors->first('nom')); ?></small>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="prix">Prix:</label>
                    <input type="number" name="prix" value="<?php echo e($plat->prix); ?>" id="validationServer03"
                        class="form-control <?php if($errors->has('prix')): ?> is-invalid <?php endif; ?>" placeholder=""
                        aria-describedby="helpId">
                    <?php if($errors->has('prix')): ?>
                    <small id="helpId" class="text-danger"><?php echo e($errors->first('prix')); ?></small>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="prix">Nom du photo:</label>
                    <input type="text" name="nom_photo" value="<?php echo e($plat->nom_photo); ?>" id="validationServer03"
                        class="form-control <?php if($errors->has('nom_photo')): ?> is-invalid <?php endif; ?>" placeholder=""
                        aria-describedby="helpId">
                    <?php if($errors->has('nom_photo')): ?>
                    <small id="helpId" class="text-danger"><?php echo e($errors->first('nom_photo')); ?></small>
                    <?php endif; ?>
                </div>

                <div class="pull-left mt-4">
                    <button type="submit" class="btn btn-primary">Enregistrer</button>
                </div>
            </form>
        </div>

    </div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/ahmad/Mohamed/Fofana/LMIOO/resources/views/plats/edit.blade.php ENDPATH**/ ?>