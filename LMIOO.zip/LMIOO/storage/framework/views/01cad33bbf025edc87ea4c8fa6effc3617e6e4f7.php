<?php $__env->startSection('title','dashboard'); ?>
<?php $__env->startSection('content'); ?>
<span class="display-2 text-center">The Dashboard Page</span>
<p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Autem dicta natus cum molestias exercitationem deserunt id,
    maiores vero qui provident minima? Id, a! Quaerat, repellendus eius consectetur consequuntur similique dicta! Lorem,
    ipsum dolor sit amet consectetur adipisicing elit. Sit voluptatibus commodi deleniti eveniet facere reprehenderit
    obcaecati neque debitis atque autem! Cupiditate quae quis incidunt ullam blanditiis recusandae voluptates laboriosam
    facilis.</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/ahmad/Mohamed/Fofana/fofana-cours/resources/views/dashboard.blade.php ENDPATH**/ ?>