<?php $__env->startSection('headings'); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/ahmad/Mohamed/Fofana/fofana-laravel/resources/views/welcome.blade.php ENDPATH**/ ?>