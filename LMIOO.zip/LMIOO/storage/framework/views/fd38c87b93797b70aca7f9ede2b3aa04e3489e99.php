<?php $__env->startSection('contenu'); ?>
<div class="col-4 offset-4 col-md-6 offset-md-3">
    <h4>L'utilisateur est connect&eacute;</h4>
    <table class="table table-hover">
        <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td scope="row"><?php echo e($LoggedUserInfo['name']); ?></td>
                <td><?php echo e($LoggedUserInfo['email']); ?></td>
                <td><a href="<?php echo e(route('auth.logout')); ?>">logout</a></td>
            </tr>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/ahmad/Mohamed/Fofana/fofana-cours/resources/views/Admin/dashboard.blade.php ENDPATH**/ ?>