<?php

namespace App\Http\Controllers;

use Barryvdh\DomPDF\Facade as PDF;
use Illuminate\Http\Request;
use App\Models\Tamponachat;
use App\Models\Plat;

class TamponachatController extends Controller
{
    public function tampon()
    {

            $tampon_achat = Tamponachat::all();
            $plat_achat = Plat::all();
            $j = 0;
            $i = 0;
            $prixtotal = 0;
            while ($i < $tampon_achat->count()) {
                for ($j = 0; $j < $plat_achat->count(); $j++) {
                    if ($tampon_achat[$i]->plat_id == $plat_achat[$j]->id) {
                        $prixtotal += $plat_achat[$j]->prix * $tampon_achat[$i]->quantite;
                    }
                }
                $i++;
            }

        $data = $this->get_achat_data();


        $pdf = PDF::loadView('facture', compact('data', 'prixtotal'));

        while (Tamponachat::first()) {

            Tamponachat::first()->delete();
        }
        return $pdf->download('facture.pdf');
    }

    public function get_achat_data()
    {
        $tampon_data = Tamponachat::groupBy('categorie')
            ->join('categories', 'categorie_id', '=', 'categories.id')
            ->join('plats', 'plat_id', '=', 'plats.id')
            ->selectRaw('plats.nom,categorie, sum(plats.prix*quantite) as prixtotal, plats.prix, sum(quantite) as quantite')
            ->get();

        return $tampon_data;
    }
}
