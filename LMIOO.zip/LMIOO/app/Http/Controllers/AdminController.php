<?php

namespace App\Http\Controllers;

use App\Models\Admin;
use Illuminate\Http\Request;
use App\Models\Plat;

class AdminController extends Controller
{
    public function save(Request $request)
    {
        $request->validate([
            'nom'=>'required',
            'prenom'=>'required',
            'email'=>'required',
            'password'=>'required'
        ]);

        Admin::create($request->all());

        return back();
    }
}
