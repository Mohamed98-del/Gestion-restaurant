<?php

namespace App\Http\Controllers;

use App\Models\Achat;
use App\Models\Client;
use Illuminate\Validation\Rule;
use Illuminate\Http\Request;
use App\Models\Plat;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Categorie extends Controller
{
    use HasFactory;
}
