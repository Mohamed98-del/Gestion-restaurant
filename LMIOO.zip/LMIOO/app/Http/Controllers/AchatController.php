<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;

use App\Models\Achat;
use App\Models\Client;
use Illuminate\Http\Request;
use App\Models\Plat;
use App\Models\Tamponachat;
use Barryvdh\DomPDF\Facade as PDF;
use Dompdf\Dompdf;
use PhpParser\Node\Stmt\StaticVar;

class AchatController extends Controller
{
    public function generatePdf()
    {
        $data = $this->get_achat_data();
        $pdf = PDF::loadView('liste', compact('data'));
        return $pdf->download('formulaire.pdf');
    }



    public function save(Request $request)
    {
        $request->validate([
            'quantite' => 'required|numeric|max:10|min:1',
            'plat_id' => 'required'
        ]);
        Achat::create($request->all());
        Tamponachat::create($request->all());


        return redirect()->route('sedar.commande')->with('success', 'Achat effectué avec succés');
    }

    public function sedar()
    {
        $achats = $this->get_achat_data();
        return view('sedar', compact('achats'));
    }

    public function get_achat_data(){
        $achats = Achat::groupBy('categorie')
            ->join('categories', 'categorie_id', '=', 'categories.id')
            ->join('plats', 'plat_id', '=', 'plats.id')
            ->selectRaw('plats.nom,categorie, sum(plats.prix*quantite) as prixtotal, plats.prix, sum(quantite) as quantite')
            ->get();


            return $achats;
    }


    public function search(Request $request){
        $request->validate([
            'motCle'=>'required|min:3'
        ]);
        $motCle = $request->motCle;
        $platsFound = DB::table('plats')
        ->join('categories', 'categorie_id', '=' ,'categories.id')
        ->where('nom', 'like', '%'.$motCle.'%')
        ->orWhere('categorie', 'like', '%'.$motCle.'%')
        ->get();
        return redirect('sedar')->with('platsFound', $platsFound);
    }
}
